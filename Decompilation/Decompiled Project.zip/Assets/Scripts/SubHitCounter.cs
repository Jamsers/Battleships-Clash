using UnityEngine;

public class SubHitCounter : MonoBehaviour
{
	public bool wasHit;

	private void Start()
	{
	}

	private void Update()
	{
	}
}
