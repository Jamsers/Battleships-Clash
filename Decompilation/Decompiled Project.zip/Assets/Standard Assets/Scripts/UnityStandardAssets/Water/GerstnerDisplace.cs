using UnityEngine;

namespace UnityStandardAssets.Water
{
	[RequireComponent(typeof(WaterBase))]
	[ExecuteInEditMode]
	public class GerstnerDisplace : Displace
	{
	}
}
